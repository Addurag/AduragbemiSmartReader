// PDF.js setup for extraction
const pdfInput = document.getElementById("pdfFile");
const extractBtn = document.getElementById("extractBtn");
const textOutput = document.getElementById("text-output");
const imageOutput = document.getElementById("image-output");

extractBtn.addEventListener("click", async () => {
  const file = pdfInput.files[0];
  if (!file) return alert("Please select a PDF file.");

  const fileReader = new FileReader();
  fileReader.onload = async function() {
    const typedarray = new Uint8Array(this.result);
    const pdf = await pdfjsLib.getDocument(typedarray).promise;
    let extractedText = "";
    imageOutput.innerHTML = "";

    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const textContent = await page.getTextContent();
      extractedText += textContent.items.map(item => item.str).join(" ");

      // Extract images
      const canvas = document.createElement("canvas");
      const context = canvas.getContext("2d");
      const viewport = page.getViewport({ scale: 1.5 });
      canvas.width = viewport.width;
      canvas.height = viewport.height;
      await page.render({ canvasContext: context, viewport }).promise;

      const img = document.createElement("img");
      img.src = canvas.toDataURL();
      imageOutput.appendChild(img);
    }

    textOutput.textContent = extractedText;
  };

  fileReader.readAsArrayBuffer(file);
});

// Read Aloud
document.getElementById("readBtn").addEventListener("click", () => {
  const text = textOutput.textContent;
  const speech = new SpeechSynthesisUtterance(text);
  speech.lang = "en-US";
  window.speechSynthesis.speak(speech);
});

// Simple Summarization
document.getElementById("summarizeBtn").addEventListener("click", () => {
  const text = textOutput.textContent;
  const sentences = text.split(". ");
  const summary = sentences.slice(0, 5).join(". ") + "...";
  alert("Summary:\n\n" + summary);
});

// Simple Q&A
document.getElementById("askBtn").addEventListener("click", () => {
  const question = document.getElementById("question").value.toLowerCase();
  const text = textOutput.textContent.toLowerCase();
  if (text.includes(question)) {
    alert("✅ Answer found in text!");
  } else {
    alert("❌ No direct answer found. Try rephrasing your question.");
  }
});